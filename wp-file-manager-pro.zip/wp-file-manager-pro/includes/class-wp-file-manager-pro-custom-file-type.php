<?php
class WP_File_Manager_Pro_Custom_File_Type {
    public function init() {
        add_filter('wpfmp_supported_file_types', array($this, 'add_custom_file_type'));
        add_action('wpfmp_handle_file_upload', array($this, 'handle_custom_file_upload'), 10, 2);
        add_action('wpfmp_handle_file_deletion', array($this, 'handle_custom_file_deletion'), 10, 2);
    }

    public function add_custom_file_type($file_types) {
        $file_types['custom'] = array(
            'label' => 'Custom File',
            'extensions' => array('custom', 'cus'),
        );
        return $file_types;
    }

    public function handle_custom_file_upload($file, $upload_dir) {
        $file_info = pathinfo($file['name']);
        if ($file_info['extension'] === 'custom' || $file_info['extension'] === 'cus') {
            // Implement custom file upload logic here
            $uploaded_file = wp_upload_bits($file['name'], null, file_get_contents($file['tmp_name']));
            return $uploaded_file;
        }
        return false;
    }

    public function handle_custom_file_deletion($file_path) {
        if (strpos($file_path, 'custom') !== false || strpos($file_path, 'cus') !== false) {
            // Implement custom file deletion logic here
            wp_delete_file($file_path);
            return true;
        }
        return false;
    }
}