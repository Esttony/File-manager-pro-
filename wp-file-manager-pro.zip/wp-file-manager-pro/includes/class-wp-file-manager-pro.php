<?php
class WP_File_Manager_Pro {
    private $admin;
    private $frontend;

    public function __construct() {
        $this->admin = new WP_File_Manager_Pro_Admin();
        $this->frontend = new WP_File_Manager_Pro_Frontend();
    }

    public function run() {
        $this->admin->init();
        $this->frontend->init();
    }
}